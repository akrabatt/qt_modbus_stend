# modbus_free

## Name

modbus_free - free a libmodbus context

## Synopsis

```c
void modbus_free(modbus_t *ctx);
```

## Description

The *modbus_free()* function shall free an allocated *modbus_t* structure.

## Return value

There is no return values.
